/******************************************************************* 
 * Name: Imani Leary  
 * Date: 10/23/2025
 * Assignment: SDC320 Week 3 GP – Abstraction 
 *  
 * This class is derived from the Quadrilateral class and provides a 
 * concrete implementation of the AreaFormula method. 
 */ 
public class Rectangle : Quadrilateral 
{ 
    public Rectangle(string fillColor, string lineColor, double length1, 
        double length2) : base(fillColor, lineColor, length1, length2) 
    { 
    } 
 
    public override string AreaFormula() 
    { 
        return "Length times Width (l x w)."; 
    } 
}