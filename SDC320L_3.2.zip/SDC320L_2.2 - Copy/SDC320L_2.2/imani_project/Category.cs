// Category.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Represents a spending or income category

public class Category
{
    // Public properties (accessible from outside)
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal BudgetLimit { get; set; }

    // Constructor
    public Category(int id, string name, decimal budgetLimit)
    {
        Id = id;
        Name = name;
        BudgetLimit = budgetLimit;
    }
}