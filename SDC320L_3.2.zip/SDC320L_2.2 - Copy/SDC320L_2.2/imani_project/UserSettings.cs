// UserSettings.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Represents user preferences and settings for the Personal Budget Tracker

public class UserSettings
{
    // User's personal name
    public string UserName { get; set; }

    // Preferred currency (e.g., USD, EUR)
    public string PreferredCurrency { get; set; }

    // Boolean to indicate whether the user wants to receive budget alerts
    public bool EnableBudgetAlerts { get; set; }

    // The threshold at which the user is notified about being over budget
    public decimal AlertThreshold { get; set; }

    // Constructor to initialize user settings with default values
    public UserSettings(string userName = "Anonymous", string preferredCurrency = "USD", bool enableBudgetAlerts = true, decimal alertThreshold = 1000)
    {
        UserName = userName;
        PreferredCurrency = preferredCurrency;
        EnableBudgetAlerts = enableBudgetAlerts;
        AlertThreshold = alertThreshold;
    }

    // Method to display user settings for debugging or user review
    public void DisplaySettings()
    {
        Console.WriteLine("=== User Settings ===");
        Console.WriteLine($"User Name: {UserName}");
        Console.WriteLine($"Preferred Currency: {PreferredCurrency}");
        Console.WriteLine($"Budget Alerts Enabled: {EnableBudgetAlerts}");
        Console.WriteLine($"Alert Threshold: {AlertThreshold}");
        Console.WriteLine("=====================");
    }
}