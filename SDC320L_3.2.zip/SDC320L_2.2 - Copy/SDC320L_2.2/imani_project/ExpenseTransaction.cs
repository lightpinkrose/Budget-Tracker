// ExpenseTransaction.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Represents an expense transaction (inherits from Transaction)

using System;

public class ExpenseTransaction : Transaction
{
    public string PaymentMethod { get; set; }

    // Constructor to initialize properties for an expense transaction
    public ExpenseTransaction(int id, decimal amount, DateTime date, string description, Category category, string paymentMethod)
        : base(id, amount, date, description, category)
    {
        PaymentMethod = paymentMethod;
    }

    // Override ToString to add payment method details
    public override string ToString()
    {
        return $"[Expense] {base.ToString()} | Payment: {PaymentMethod}";
    }
}