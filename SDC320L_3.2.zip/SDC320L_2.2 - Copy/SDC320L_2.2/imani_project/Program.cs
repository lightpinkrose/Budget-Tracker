﻿// Name: Imani Leary 
// Date: 10/26/2025
// Purpose: Entry point for Week 2 Project Lab. Demonstrates interface, inheritance, polymorphism.
 
using System; 
using System.Collections.Generic; 
 
class Program 
{ 
    static void Main() 
    { 
        Console.WriteLine("=== Week 2 Project - Personal Budget Tracker ==="); 
        Console.WriteLine("Student: Imani Leary\n"); 
        Console.WriteLine("Welcome to your Personal Budget Tracker!"); 
        Console.WriteLine("This program demonstrates OOP concepts: Inheritance, Interface, Polymorphism, and Composition.\n"); 
 
        // Create categories 
        var foodCategory = new Category(1, "Food", 200); 
        var utilitiesCategory = new Category(2, "Utilities", 150); 
 
        // Create transactions (INHERITANCE) 
        var income = new IncomeTransaction(1, 1000, DateTime.Now, "Paycheck", null, "Employer Inc."); 
        var grocery = new ExpenseTransaction(2, 80, DateTime.Now, "Groceries", foodCategory, "Debit Card"); 
        var electricity = new ExpenseTransaction(3, 160, DateTime.Now, "Electric Bill", utilitiesCategory, "Bank Transfer"); 
 
        // Display transactions (POLYMORPHISM via base class) 
        List<Transaction> transactions = new List<Transaction> { income, grocery, electricity }; 
        foreach (var t in transactions) 
        { 
            Console.WriteLine(t); // Calls overridden ToString() 
        } 
 
        Console.WriteLine(); 
 
        // Interface + Polymorphism demonstration 
        // CategoryBudgetTracker implements IBudgetTrackable 
        IBudgetTrackable foodTracker = new CategoryBudgetTracker(foodCategory); 
        IBudgetTrackable utilitiesTracker = new CategoryBudgetTracker(utilitiesCategory); 
 
        // Add expenses to trackers (COMPOSITION) 
        ((CategoryBudgetTracker)foodTracker).Transactions.Add(grocery); 
        ((CategoryBudgetTracker)utilitiesTracker).Transactions.Add(electricity); 
 
        // Check if over budget 
        List<IBudgetTrackable> trackers = new List<IBudgetTrackable> { foodTracker, utilitiesTracker }; 
 
        foreach (var tracker in trackers) 
        { 
            Console.WriteLine($"Category: {((CategoryBudgetTracker)tracker).Category.Name}"); 
            Console.WriteLine($"Total Spent: ${tracker.GetTotalSpent()}"); 
            Console.WriteLine(tracker.IsOverBudget() 
                ? "Over Budget!" 
                : "Within Budget."); 
            Console.WriteLine(); 
        } 
 
        Console.WriteLine("=== End of Demonstration ==="); 
    } 
}