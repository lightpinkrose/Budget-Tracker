// CategoryBudgetTracker.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Implements IBudgetTrackable to track spending per category

using System;
using System.Collections.Generic;
using System.Linq;

public class CategoryBudgetTracker : IBudgetTrackable
{
    // Category object is now publicly accessible
    public Category Category { get; set; }
    public List<ExpenseTransaction> Transactions { get; set; }

    // Constructor to initialize with a category and an empty transaction list
    public CategoryBudgetTracker(Category category)
    {
        Category = category ?? throw new ArgumentNullException(nameof(category));  // Null check for safety
        Transactions = new List<ExpenseTransaction>();
    }

    // Returns the total spent in the category
    public decimal GetTotalSpent()
    {
        return Transactions.Sum(t => t.Amount);
    }

    // Checks if the spending in this category exceeds the budget
    public bool IsOverBudget()
    {
        return GetTotalSpent() > Category?.BudgetLimit;
    }
}