// Transaction.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Base class representing a financial transaction (can be an expense or income)

using System;

public abstract class Transaction
{
    public int Id { get; set; }
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
    public string Description { get; set; }
    public Category? Category { get; set; }  // Nullable Category

    // Constructor to initialize transaction properties
    public Transaction(int id, decimal amount, DateTime date, string description, Category? category)
    {
        Id = id;
        Amount = amount;
        Date = date;
        Description = description;
        Category = category;
    }

    // Default implementation of ToString (can be overridden by derived classes)
    public virtual string ToString()
    {
        return $"{Date.ToShortDateString()} | {Description} | {Category?.Name} | ${Amount}";
    }
}