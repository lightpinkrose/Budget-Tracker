// IncomeTransaction.cs
// Name: Imani Leary
// Date: 10/26/2025
// Purpose: Represents an income transaction (inherits from Transaction)

using System;

public class IncomeTransaction : Transaction
{
    public string Source { get; set; }

    // Constructor
    public IncomeTransaction(int id, decimal amount, DateTime date, string description, Category category, string source)
        : base(id, amount, date, description, category)
    {
        Source = source;
    }

    // Overridden ToString method
    public override string ToString()
    {
        return $"[Income] {base.ToString()} | Source: {Source}";
    }
}