// Name: Imani Leary 
// Date: 10/15/2025
// Purpose: Represents a spending or income category 
 
public class Category 
{ 
    public int Id { get; set; } 
    public string Name { get; set; } 
    public decimal BudgetLimit { get; set; } 
 
    public Category(int id, string name, decimal budgetLimit) 
    { 
        Id = id; 
        Name = name; 
        BudgetLimit = budgetLimit; 
    } 
}