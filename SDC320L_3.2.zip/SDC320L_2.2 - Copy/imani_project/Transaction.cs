// Name: Imani Leary 
// Date: 10/15/2025 
// Purpose: Base class representing a financial transaction 
 
using System; 
 
public class Transaction 
{ 
    public int Id { get; set; } 
    public decimal Amount { get; set; } 
    public DateTime Date { get; set; } 
    public string Description { get; set; } 
    public Category Category { get; set; } 
 
    public Transaction(int id, decimal amount, DateTime date, string description, Category category) 
    { 
        Id = id; 
        Amount = amount; 
        Date = date; 
        Description = description; 
        Category = category; 
    } 
 
    public override string ToString() 
    { 
        return $"{Date.ToShortDateString()} | {Description} | {Category?.Name} | ${Amount}"; 
    } 
}