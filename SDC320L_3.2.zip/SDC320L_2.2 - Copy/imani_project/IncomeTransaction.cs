// Name: Imani Leary 
// Date: 10/15/2025
// Purpose: Represents an income transaction (inherits from Transaction) 
 
using System; 
 
public class IncomeTransaction : Transaction 
{ 
    public string Source { get; set; } 
 
    public IncomeTransaction(int id, decimal amount, DateTime date, string description, Category category, string source) 
        : base(id, amount, date, description, category) 
    { 
        Source = source; 
    } 
 
    public override string ToString() 
    { 
        return $"[Income] {base.ToString()} | Source: {Source}"; 
    } 
}