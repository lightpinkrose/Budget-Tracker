// Name: Imani Leary 
// Date: 10/15/2025
// Purpose: Interface for classes that support budget tracking 
 
public interface IBudgetTrackable 
{ 
    decimal GetTotalSpent(); 
    bool IsOverBudget(); 
}