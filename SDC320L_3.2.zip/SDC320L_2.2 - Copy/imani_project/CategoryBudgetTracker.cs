// Name: Imani Leary 
// Date: 10/15/2025
// Purpose: Implements IBudgetTrackable to track spending per category 
 
using System.Collections.Generic; 
using System.Linq; 
 
public class CategoryBudgetTracker : IBudgetTrackable 
{ 
    public Category Category { get; set; } 
    public List<ExpenseTransaction> Transactions { get; set; } 
 
    public CategoryBudgetTracker(Category category) 
    { 
        Category = category; 
        Transactions = new List<ExpenseTransaction>(); 
    } 
 
    public decimal GetTotalSpent() 
    { 
        return Transactions.Sum(t => t.Amount); 
    } 
 
    public bool IsOverBudget() 
    { 
        return GetTotalSpent() > Category.BudgetLimit; 
    } 
}