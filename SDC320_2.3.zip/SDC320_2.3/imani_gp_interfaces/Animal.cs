/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 GP – Interface 
 *  
 * Interface class IAnimal - defines all methods that classes that 
 * implement this interface must implement. 
*/ 
interface IAnimal 
{ 
    string GetName(); 
    string MakeSound(); 
    void Move(string start, string end); 
}