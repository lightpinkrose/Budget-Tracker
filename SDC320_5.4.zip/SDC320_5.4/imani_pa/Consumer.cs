using System;
using System.Threading;

namespace Imani_PA_Concurrency
{
    public class Consumer
    {
        private string _name;
        private int _sleepTime;
        private int _startConsuming;
        private int _stopConsuming;
        private BlockingBuffer _buffer;


        public Consumer(string name, int sleepTime, int startConsuming, int stopConsuming, BlockingBuffer buffer)
        {
            _name = name;
            _sleepTime = sleepTime;
            _startConsuming = startConsuming;
            _stopConsuming = stopConsuming;
            _buffer = buffer;
        }

        public void Run()
        {
            for (int i = _startConsuming; i <= _stopConsuming; i++)
            {
                Thread.Sleep(_sleepTime * 1000);
                _buffer.BlockingGet(_name);
            }
        }
    }
}