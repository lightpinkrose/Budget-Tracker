using System;
using System.Threading;

namespace Imani_PA_Concurrency
{
    public class Producer
    {
        private string _name;
        private int _sleepTime;
        private int _startProducing;
        private int _stopProducing;
        private BlockingBuffer _buffer;

        /// <summary>
        /// Constructor for the Producer class.
        /// </summary>
        /// <param name="name">The name of the producer.</param>
        /// <param name="sleepTime">The time to sleep between productions (in seconds).</param>
        /// <param name="startProducing">The start index of production.</param>
        /// <param name="stopProducing">The stop index of production.</param>
        /// <param name="buffer">The shared buffer where items will be added.</param>
        public Producer(string name, int sleepTime, int startProducing, int stopProducing, BlockingBuffer buffer)
        {
            _name = name;
            _sleepTime = sleepTime;
            _startProducing = startProducing;
            _stopProducing = stopProducing;
            _buffer = buffer;
        }

        /// <summary>
        /// Run method for the producer to produce items in the specified range.
        /// </summary>
        public void Run()
        {
            for (int i = _startProducing; i <= _stopProducing; i++)
            {
                Thread.Sleep(_sleepTime * 1000);
                _buffer.BlockingPut(_name, i);
            }
        }
    }
}