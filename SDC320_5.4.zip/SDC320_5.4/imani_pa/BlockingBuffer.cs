using System;
using System.Collections.Concurrent;
using System.Threading;

namespace Imani_PA_Concurrency
{
    public class BlockingBuffer
    {
        private BlockingCollection<int> _buffer;

        public BlockingBuffer(int size)
        {
            _buffer = new BlockingCollection<int>(size);
        }

        public void BlockingPut(string name, int item)
        {
            _buffer.Add(item);
            Console.WriteLine($"{name} added {item} to the buffer.");
        }
        public int BlockingGet(string name)
        {
            int item = _buffer.Take();
            Console.WriteLine($"{name} retrieved {item} from the buffer.");
            return item;
        }
    }
}