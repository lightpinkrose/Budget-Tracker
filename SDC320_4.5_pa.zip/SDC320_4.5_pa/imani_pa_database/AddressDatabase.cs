// Name: Imani Leary
// Date: 10/29/2025
// Assignment: SDC320 Performance Assessment - Database
// Description: This class manages the SQLite database operations like creating the database, creating the table, 
// and performing CRUD operations on the address records.

using System;
using System.Collections.Generic;
using System.Data.SQLite;

public class AddressDatabase
{
    private string _connectionString;

    // Constructor to initialize the database connection
    public AddressDatabase(string dbName)
    {
        _connectionString = $"Data Source={dbName}.db;Version=3;";
    }

    // Create or connect to the database and create the Addresses table if it doesn't exist
    public void InitializeDatabase()
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string createTableQuery = @"
                CREATE TABLE IF NOT EXISTS Addresses (
                    ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    StreetAddress1 TEXT NOT NULL,
                    StreetAddress2 TEXT,
                    City TEXT NOT NULL,
                    State TEXT NOT NULL,
                    ZipCode TEXT NOT NULL
                );";

            using (var command = new SQLiteCommand(createTableQuery, connection))
            {
                command.ExecuteNonQuery();
            }
        }
    }

    // Add a new address record
    public void AddAddress(Address address)
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string insertQuery = @"
                INSERT INTO Addresses (StreetAddress1, StreetAddress2, City, State, ZipCode) 
                VALUES (@StreetAddress1, @StreetAddress2, @City, @State, @ZipCode);";

            using (var command = new SQLiteCommand(insertQuery, connection))
            {
                command.Parameters.AddWithValue("@StreetAddress1", address.StreetAddress1);
                command.Parameters.AddWithValue("@StreetAddress2", address.StreetAddress2 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@City", address.City);
                command.Parameters.AddWithValue("@State", address.State);
                command.Parameters.AddWithValue("@ZipCode", address.ZipCode);

                command.ExecuteNonQuery();
            }
        }
    }

    // Retrieve a single address by ID
    public Address GetAddressById(int id)
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string selectQuery = "SELECT * FROM Addresses WHERE ID = @ID;";
            using (var command = new SQLiteCommand(selectQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Address(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                            reader.GetString(3),
                            reader.GetString(4),
                            reader.GetString(5)
                        );
                    }
                    else
                    {
                        return null;
                    }
                }
            }
        }
    }

    // Retrieve all addresses from the database
    public List<Address> GetAllAddresses()
    {
        var addresses = new List<Address>();
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string selectQuery = "SELECT * FROM Addresses;";
            using (var command = new SQLiteCommand(selectQuery, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        addresses.Add(new Address(
                            reader.GetInt32(0),
                            reader.GetString(1),
                            reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                            reader.GetString(3),
                            reader.GetString(4),
                            reader.GetString(5)
                        ));
                    }
                }
            }
        }
        return addresses;
    }

    // Update an address record by ID
    public void UpdateAddress(Address address)
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string updateQuery = @"
                UPDATE Addresses 
                SET StreetAddress1 = @StreetAddress1, 
                    StreetAddress2 = @StreetAddress2, 
                    City = @City, 
                    State = @State, 
                    ZipCode = @ZipCode 
                WHERE ID = @ID;";

            using (var command = new SQLiteCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", address.ID);
                command.Parameters.AddWithValue("@StreetAddress1", address.StreetAddress1);
                command.Parameters.AddWithValue("@StreetAddress2", address.StreetAddress2 ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@City", address.City);
                command.Parameters.AddWithValue("@State", address.State);
                command.Parameters.AddWithValue("@ZipCode", address.ZipCode);

                command.ExecuteNonQuery();
            }
        }
    }

    // Delete an address record by ID
    public void DeleteAddress(int id)
    {
        using (var connection = new SQLiteConnection(_connectionString))
        {
            connection.Open();

            string deleteQuery = "DELETE FROM Addresses WHERE ID = @ID;";
            using (var command = new SQLiteCommand(deleteQuery, connection))
            {
                command.Parameters.AddWithValue("@ID", id);
                command.ExecuteNonQuery();
            }
        }
    }
}