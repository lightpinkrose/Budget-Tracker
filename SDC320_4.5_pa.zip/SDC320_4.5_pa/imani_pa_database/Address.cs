// Name: Imani Leary
// Date: 10/29/2025
// Assignment: SDC320 Performance Assessment - Database
// Description: This class represents a mailing address with properties such as street address, city, state, zip code, and ID.

public class Address
{
    public int ID { get; set; }
    public string StreetAddress1 { get; set; }
    public string StreetAddress2 { get; set; }
    public string City { get; set; }
    public string State { get; set; }
    public string ZipCode { get; set; }

    // Constructor for easy initialization
    public Address(int id, string streetAddress1, string streetAddress2, string city, string state, string zipCode)
    {
        ID = id;
        StreetAddress1 = streetAddress1;
        StreetAddress2 = streetAddress2;
        City = city;
        State = state;
        ZipCode = zipCode;
    }
}