// Name: Imani Leary
// Date: 10/29/2025
// Assignment: SDC320 Performance Assessment - Database
// Description: This class handles the application's logic for creating, reading, updating, 
// and deleting address records in the SQLite database.

using System;
using System.Linq;

public class AddressService
{
    private AddressDatabase _addressDatabase;

    public AddressService(string dbName)
    {
        _addressDatabase = new AddressDatabase(dbName);
        _addressDatabase.InitializeDatabase();
    }

    public void AddSampleAddresses()
    {
        var sampleAddresses = new[]
        {
            new Address(0, "123 Main Street", "Suite 101", "Some City", "ST", "12345"),
            new Address(0, "456 Elm Street", "", "Other City", "OT", "67890"),
            new Address(0, "789 Oak Avenue", "Apt 303", "Big City", "BC", "10112"),
            new Address(0, "101 Pine Road", "", "Small Town", "ST", "20234")
        };

        foreach (var address in sampleAddresses)
        {
            _addressDatabase.AddAddress(address);
        }
    }

    public void PrintAllAddresses()
    {
        var addresses = _addressDatabase.GetAllAddresses();
        Console.WriteLine("Printing all addresses in the database:");

        foreach (var address in addresses)
        {
            Console.WriteLine($"Address {address.ID}:");
            Console.WriteLine(address.StreetAddress1);
            if (!string.IsNullOrEmpty(address.StreetAddress2)) Console.WriteLine(address.StreetAddress2);
            Console.WriteLine($"{address.City}, {address.State} {address.ZipCode}\n");
        }
    }

    public void PrintAddressById(int id)
    {
        var address = _addressDatabase.GetAddressById(id);
        if (address != null)
        {
            Console.WriteLine($"Address {address.ID}:");
            Console.WriteLine(address.StreetAddress1);
            if (!string.IsNullOrEmpty(address.StreetAddress2)) Console.WriteLine(address.StreetAddress2);
            Console.WriteLine($"{address.City}, {address.State} {address.ZipCode}\n");
        }
        else
        {
            Console.WriteLine("Address not found for ID: " + id);
        }
    }

    public void UpdateAndPrintAddress(Address address)
    {
        _addressDatabase.UpdateAddress(address);
        PrintAddressById(address.ID);
    }

    public void DeleteAndPrintAllAddresses(int id)
    {
        _addressDatabase.DeleteAddress(id);
        PrintAllAddresses();
    }
}