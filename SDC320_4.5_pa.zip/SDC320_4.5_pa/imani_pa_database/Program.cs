﻿// Program.cs
// Name: Imani Leary
// Date: 10/29/2025
// Assignment: SDC320 Performance Assessment - Database
// Description: This is the main program that runs the SQLite CRUD operations for the Address database.

using System;

public partial class Program  // Add the 'partial' modifier here
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Imani Leary - Week 4 Database PA");

        var addressService = new AddressService("YourName");

        // Add sample addresses
        addressService.AddSampleAddresses();

        // Print all addresses
        addressService.PrintAllAddresses();

        // Attempt to retrieve an address with an invalid ID
        Console.WriteLine("Attempting to retrieve an address with invalid ID:");
        addressService.PrintAddressById(999);

        // Update an address and print the updated record
        var updatedAddress = new Address(1, "123 Main Street", "Suite 105", "Some City", "ST", "12345");
        Console.WriteLine("Updating an address:");
        addressService.UpdateAndPrintAddress(updatedAddress);

        // Delete an address and print remaining addresses
        Console.WriteLine("Deleting an address:");
        addressService.DeleteAndPrintAllAddresses(2);
    }
}