using System;

namespace Imani_FinalPractical
{
    /// House class representing a specific type of building
    /// Demonstrates Inheritance, Polymorphism, and Use of Constructors
    public class House : Building
    {
        public int NumberOfRooms { get; set; } // Number of rooms in the house

        /// Constructor for the House class
        /// Demonstrates Use of Constructors

        /// <param name="name">Name of the house</param>
        /// <param name="numberOfRooms">Number of rooms in the house</param>
        public House(string name, int numberOfRooms)
            : base(name, "House") // Calling the base class constructor
        {
            NumberOfRooms = numberOfRooms;
        }

        /// Display information specific to the House class
        /// Demonstrates Polymorphism
        public override void DisplayInfo()
        {
            Console.WriteLine($"{Name} is a {Type} with {NumberOfRooms} rooms.");
        }
    }
}