﻿using System;
using System.Collections.Generic;

namespace Imani_FinalPractical
{
    class Program
    {
        static void Main(string[] args)
        {
            // Print introductory line
            Console.WriteLine("Imani Leary - Week 5 Final Practical Exam");

            // Create the BuildingList object (composition)
            BuildingList buildingList = new BuildingList();

            // Create House objects (demonstrates inheritance and constructor use)
            House house1 = new House("Green House", 5);
            House house2 = new House("Red House", 3);
            House house3 = new House("Blue House", 7);
            House house4 = new House("Yellow House", 4);
            House house5 = new House("White House", 6);

            // Add House objects to the list (demonstrates composition)
            buildingList.AddBuilding(house1);
            buildingList.AddBuilding(house2);
            buildingList.AddBuilding(house3);
            buildingList.AddBuilding(house4);
            buildingList.AddBuilding(house5);

            // Log messages (demonstrates file I/O)
            buildingList.LogMessage("Building list created with 5 houses.");
            buildingList.LogMessage("Displaying the list of buildings iteratively.");
            buildingList.LogMessage("Displaying the list of buildings recursively.");
            buildingList.LogMessage("End of the building list processing.");

            // Print the list iteratively
            Console.WriteLine("\nIterative Display:");
            buildingList.PrintListIteratively();

            // Print the list recursively
            Console.WriteLine("\nRecursive Display:");
            buildingList.PrintListRecursively();

            // Print the contents of the log file
            Console.WriteLine("\nLog File Contents:");
            buildingList.PrintLog();
        }
    }
}