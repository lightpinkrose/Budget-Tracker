using System;

namespace Imani_FinalPractical
{

    public abstract class Building
    {
        public string Name { get; set; } // Property for building name
        public string Type { get; set; } // Property for building type

        /// Constructor to initialize building name and type
        /// Demonstrates Use of Constructors

        /// <param name="name">Name of the building</param>
        /// <param name="type">Type of the building</param>
        public Building(string name, string type)
        {
            Name = name;
            Type = type;
        }
        /// Abstract method to be implemented by derived classes to display building info
        /// Demonstrates Polymorphism
        public abstract void DisplayInfo();
    }
}