using System;
using System.Collections.Generic;
using System.IO;

namespace Imani_FinalPractical
{
    /// Class to handle the list of buildings, including file I/O and recursive/iterative printing
    /// Demonstrates Composition, Text File Data Storage/Retrieval
    public class BuildingList
    {
        private List<Building> buildings; // Composition: A BuildingList is composed of multiple Building objects.

        public BuildingList()
        {
            buildings = new List<Building>(); // Initializes the list of buildings
        }

        /// <summary>
        /// Adds a building to the list.
        /// </summary>
        public void AddBuilding(Building building)
        {
            buildings.Add(building);
        }

        /// <summary>
        /// Prints all buildings iteratively.
        /// </summary>
        public void PrintListIteratively()
        {
            foreach (var building in buildings)
            {
                building.DisplayInfo();
            }
        }

        /// Prints all buildings recursively
        public void PrintListRecursively(int index = 0)
        {
            if (index < buildings.Count)
            {
                buildings[index].DisplayInfo();
                PrintListRecursively(index + 1);
            }
        }

        /// Logs messages to a text file
        /// Demonstrates Text File Data Storage/Retrieval
        public void LogMessage(string message)
        {
            using (StreamWriter sw = new StreamWriter("yourname_log.txt", true))
            {
                sw.WriteLine(message);
            }
        }

        /// Prints the log file contents to the console
        public void PrintLog()
        {
            if (File.Exists("yourname_log.txt"))
            {
                string[] lines = File.ReadAllLines("yourname_log.txt");
                foreach (var line in lines)
                {
                    Console.WriteLine(line);
                }
            }
            else
            {
                Console.WriteLine("Log file does not exist.");
            }
        }
    }
}