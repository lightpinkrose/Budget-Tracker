public class Category
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal BudgetLimit { get; set; }

    // Constructor for Category class
    public Category(int id, string name, decimal budgetLimit)
    {
        Id = id;
        Name = name;
        BudgetLimit = budgetLimit;
    }
}