using System;
using System.Collections.Generic;

public class CategoryBudgetTracker : IBudgetTrackable
{
    public Category Category { get; set; }
    public List<Transaction> Transactions { get; set; }

    // Constructor for CategoryBudgetTracker class
    public CategoryBudgetTracker(Category category)
    {
        Category = category;
        Transactions = new List<Transaction>();
    }

    // Add transaction to the list
    public void AddTransaction(Transaction transaction)
    {
        Transactions.Add(transaction);
    }

    // Get total spent for the category
    public decimal GetTotalSpent()
    {
        decimal total = 0;
        foreach (var transaction in Transactions)
        {
            if (transaction is ExpenseTransaction)
            {
                total += transaction.Amount;
            }
        }
        return total;
    }

    // Check if the category is over budget
    public bool IsOverBudget()
    {
        return GetTotalSpent() > Category.BudgetLimit;
    }
}