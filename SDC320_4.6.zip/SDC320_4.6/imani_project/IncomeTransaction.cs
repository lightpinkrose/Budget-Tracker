public class IncomeTransaction : Transaction
{
    public string Source { get; set; } // e.g., Salary, Freelance

    // Constructor for IncomeTransaction class
    public IncomeTransaction(int id, decimal amount, DateTime date, string description, Category category, string source)
        : base(id, amount, date, description, category)
    {
        Source = source;
    }

    // Override ToString() to return income-specific details
    public override string ToString()
    {
        return $"Income: {Description}, Amount: {Amount}, Source: {Source}, Date: {Date.ToShortDateString()}, Category: {Category.Name}";
    }
}