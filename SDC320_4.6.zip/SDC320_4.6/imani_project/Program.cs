﻿using System;

/*************************************************
*Name: Imani Leary
*Date: 10/23/2025
*
*Assignment: SDC320 3.8 Project - Class Implementation
*/

class Program
{
    static void Main()
    {
        // Create categories
        Category foodCategory = new Category(1, "Food", 500);
        Category rentCategory = new Category(2, "Rent", 1000);

        // Create transactions
        IncomeTransaction salary = new IncomeTransaction(1, 3000, DateTime.Now, "Salary", foodCategory, "Salary");
        ExpenseTransaction foodExpense = new ExpenseTransaction(2, 50, DateTime.Now, "Grocery Shopping", foodCategory, "Credit Card");

        // Track transactions in CategoryBudgetTracker
        CategoryBudgetTracker foodTracker = new CategoryBudgetTracker(foodCategory);
        foodTracker.AddTransaction(salary);
        foodTracker.AddTransaction(foodExpense);

        // Display whether the category is over budget
        Console.WriteLine($"Is Food Category Over Budget? {foodTracker.IsOverBudget()}");

        // Generate a budget summary
        BudgetSummary budgetSummary = new BudgetSummary(DateTime.Now, new System.Collections.Generic.List<Transaction> { salary, foodExpense });
        budgetSummary.PrintSummary();
    }
}