/**************************************************************
* Name: Imani Leary
* Date: 10/12/2025
* Assignment: 1.5 PA Demonstrating Inheritance
*
*/
namespace InheritanceDemo
{
    /// <summary>
    /// Your Name
    /// 2025-10-12
    /// SDC310 Performance Assessment - Inheritance
    /// Description: Represents a car, derived from Transportation
    /// </summary>
    public class Car : Transportation
    {
        public bool IsAutomatic { get; set; }
        public bool HasSunRoof { get; set; }
        public double StorageCapacity { get; set; }

        public Car(string color, int numberOfSeats, double engineSize, bool isAutomatic, bool hasSunRoof, double storageCapacity)
            : base(color, numberOfSeats, engineSize)
        {
            IsAutomatic = isAutomatic;
            HasSunRoof = hasSunRoof;
            StorageCapacity = storageCapacity;
        }

        public override string ToString()
        {
            return base.ToString() +
                   $", Automatic: {IsAutomatic}, Sun Roof: {HasSunRoof}, Storage Capacity: {StorageCapacity} cu ft";
        }
    }
}
