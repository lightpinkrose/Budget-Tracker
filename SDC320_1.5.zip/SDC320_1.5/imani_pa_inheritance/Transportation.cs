/**************************************************************
* Name: Imani Leary
* Date: 10/12/2025
* Assignment: 1.5 PA Demonstrating Inheritance
*
*/
using System;

namespace InheritanceDemo
{
    /// <summary>
    /// Your Name
    /// 2025-10-12
    /// SDC310 Performance Assessment - Inheritance
    /// Description: Base class representing general transportation
    /// </summary>
    public class Transportation
    {
        public string Color { get; set; }
        public int NumberOfSeats { get; set; }
        public double EngineSize { get; set; }

        public Transportation(string color, int numberOfSeats, double engineSize)
        {
            Color = color;
            NumberOfSeats = numberOfSeats;
            EngineSize = engineSize;
        }

        public override string ToString()
        {
            return $"Color: {Color}, Seats: {NumberOfSeats}, Engine Size: {EngineSize}L";
        }
    }
}
