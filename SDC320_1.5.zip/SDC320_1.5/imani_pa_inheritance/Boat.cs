/**************************************************************
* Name: Imani Leary
* Date: 10/12/2025
* Assignment: 1.5 PA Demonstrating Inheritance
*
*/
namespace InheritanceDemo
{
    /// <summary>
    /// Your Name
    /// 2025-10-12
    /// SDC310 Performance Assessment - Inheritance
    /// Description: Represents a boat, derived from Transportation
    /// </summary>
    public class Boat : Transportation
    {
        public string HullType { get; set; }

        public Boat(string color, int numberOfSeats, double engineSize, string hullType)
            : base(color, numberOfSeats, engineSize)
        {
            HullType = hullType;
        }

        public override string ToString()
        {
            return base.ToString() + $", Hull Type: {HullType}";
        }
    }
}
