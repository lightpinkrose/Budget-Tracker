﻿/**************************************************************
* Name: Imani Leary
* Date: 10/12/2025
* Assignment: 1.5 PA Demonstrating Inheritance
*
*/
using System;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Imani Leary - Week 1 Inheritance Performance Assessment\n");

            // Create Car
            Car myCar = new Car("Red", 5, 2.0, true, true, 15.5);
            Console.WriteLine("Car Details:");
            Console.WriteLine(myCar.ToString());
            Console.WriteLine();

            // Create Bicycle
            Bicycle myBike = new Bicycle("Blue", 1, 0.0, true);
            Console.WriteLine("Bicycle Details:");
            Console.WriteLine(myBike.ToString());
            Console.WriteLine();

            // Create Boat
            Boat myBoat = new Boat("White", 8, 3.5, "Catamaran");
            Console.WriteLine("Boat Details:");
            Console.WriteLine(myBoat.ToString());
            Console.WriteLine();

            // Print Car properties individually
            Console.WriteLine("Car Specific Properties:");
            Console.WriteLine($"Color: {myCar.Color}");
            Console.WriteLine($"Number of Seats: {myCar.NumberOfSeats}");
            Console.WriteLine($"Engine Size: {myCar.EngineSize}L");
            Console.WriteLine($"Automatic Transmission: {myCar.IsAutomatic}");
            Console.WriteLine($"Sun Roof: {myCar.HasSunRoof}");
            Console.WriteLine($"Storage Capacity: {myCar.StorageCapacity} cu ft");
        }
    }
}