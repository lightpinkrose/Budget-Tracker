/**************************************************************
* Name: Imani Leary
* Date: 10/12/2025
* Assignment: 1.5 PA Demonstrating Inheritance
*
*/
namespace InheritanceDemo
{
    /// <summary>
    /// Your Name
    /// 2025-10-12
    /// SDC310 Performance Assessment - Inheritance
    /// Description: Represents a bicycle, derived from Transportation
    /// </summary>
    public class Bicycle : Transportation
    {
        public bool HasBasket { get; set; }

        public Bicycle(string color, int numberOfSeats, double engineSize, bool hasBasket)
            : base(color, numberOfSeats, engineSize)
        {
            HasBasket = hasBasket;
        }

        public override string ToString()
        {
            return base.ToString() + $", Has Basket: {HasBasket}";
        }
    }
}
