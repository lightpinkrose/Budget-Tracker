﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Print header
        Console.WriteLine("Imani Leary - Week 2 Polymorphism Performance Assessment");
        
        // Create instances of the classes
        Building building = new Building("123 Main St", 2000);
        Condominium condo = new Condominium("456 Oak Ave", 1200, 5);
        House house = new House("789 Pine Blvd", 2500, 600);
        SplitLevel splitLevel1 = new SplitLevel("101 Maple Dr", 2800, 800, 3);
        SplitLevel splitLevel2 = new SplitLevel("102 Maple Dr", 2700, 700, 2);
        
        // Create a List of Building and add all instances to it
        List<Building> buildings = new List<Building>
        {
            building, condo, house, splitLevel1, splitLevel2
        };
        
        // Create a List of House and add applicable instances (House and SplitLevel) to it
        List<House> houses = new List<House>
        {
            house, splitLevel1, splitLevel2
        };

        // Print the contents of both lists
        Console.WriteLine("\n--- All Buildings ---");
        foreach (Building b in buildings)
        {
            PrintBuildingInfo(b);
        }

        Console.WriteLine("\n--- Houses (including SplitLevels) ---");
        foreach (House h in houses)
        {
            PrintBuildingInfo(h);
        }
    }

    // Private method to print building information
    private static void PrintBuildingInfo(Building building)
    {
        Console.WriteLine(building.ToString());
    }
}