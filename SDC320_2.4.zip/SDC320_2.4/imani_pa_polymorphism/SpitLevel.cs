/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Polymorphism Performance Assessment
 *  
 * SplitLevel class represents a specific type of house with 
 * multiple levels and additional properties specific to this type.
*/ 
public class SplitLevel : House
{
    // Property for the number of levels
    public int NumberOfLevels { get; set; }

    // Constructor
    public SplitLevel(string address, double squareFootage, double backyardSize, int numberOfLevels)
        : base(address, squareFootage, backyardSize)
    {
        NumberOfLevels = numberOfLevels;
    }

    // Override ToString method to include number of levels
    public override string ToString()
    {
        return base.ToString() + $", Number of Levels: {NumberOfLevels}";
    }
}