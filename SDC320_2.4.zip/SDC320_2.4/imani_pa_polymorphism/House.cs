/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Polymorphism Performance Assessment
 *  
 * House class represents a specific building type that includes 
 * a backyard size in addition to the general building properties.
*/ 
public class House : Building
{
    // Property for the backyard size
    public double BackyardSize { get; set; }

    // Constructor
    public House(string address, double squareFootage, double backyardSize)
        : base(address, squareFootage)
    {
        BackyardSize = backyardSize;
    }

    // Override ToString method to include backyard size
    public override string ToString()
    {
        return base.ToString() + $", Backyard Size: {BackyardSize} sqft";
    }
}