/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Polymorphism Performance Assessment
 *  
 * Building class represents a general building with common properties 
 * like address and square footage. It provides a method to display 
 * these properties as a formatted string.
*/ 
public class Building
{
    // Properties
    public string Address { get; set; }
    public double SquareFootage { get; set; }

    // Constructor
    public Building(string address, double squareFootage)
    {
        Address = address;
        SquareFootage = squareFootage;
    }

    // Override ToString method to return building information
    public override string ToString()  // <-- Use 'override' here
    {
        return $"Address: {Address}, Square Footage: {SquareFootage} sqft";
    }
}