/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Polymorphism Performance Assessment
 *  
 * Condominium class represents a specific type of building that 
 * includes the floor number along with the general building properties.
*/ 
public class Condominium : Building
{
    // Additional property for condominium
    public int FloorNumber { get; set; }

    // Constructor
    public Condominium(string address, double squareFootage, int floorNumber)
        : base(address, squareFootage)
    {
        FloorNumber = floorNumber;
    }

    // Override ToString method to include floor number
    public override string ToString()
    {
        return base.ToString() + $", Floor Number: {FloorNumber}";
    }
}