using System;
using System.Collections.Generic;

public class BudgetSummary
{
    public DateTime Month { get; set; }
    public List<Transaction> Transactions { get; set; }

    // Constructor for BudgetSummary class
    public BudgetSummary(DateTime month, List<Transaction> transactions)
    {
        Month = month;
        Transactions = transactions;
    }

    // Generate a summary of income and expenses
    public void GenerateSummary()
    {
        decimal totalIncome = 0;
        decimal totalExpenses = 0;

        foreach (var transaction in Transactions)
        {
            if (transaction is IncomeTransaction)
            {
                totalIncome += transaction.Amount;
            }
            else if (transaction is ExpenseTransaction)
            {
                totalExpenses += transaction.Amount;
            }
        }

        Console.WriteLine($"Summary for {Month.ToString("MMMM yyyy")}:");
        Console.WriteLine($"Total Income: {totalIncome:C}");
        Console.WriteLine($"Total Expenses: {totalExpenses:C}");
        Console.WriteLine($"Net Balance: {totalIncome - totalExpenses:C}");
    }

    // Print the summary to the console
    public void PrintSummary()
    {
        GenerateSummary();
    }
}