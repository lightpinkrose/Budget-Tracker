using System;
using System.Collections.Generic;

public class UserSettings
{
    public List<Category> Categories { get; set; }
    public Dictionary<string, decimal> BudgetLimits { get; set; }

    // Constructor for UserSettings class
    public UserSettings()
    {
        Categories = new List<Category>();
        BudgetLimits = new Dictionary<string, decimal>();
    }

    // Add a category to the user's settings
    public void AddCategory(Category category)
    {
        Categories.Add(category);
    }

    // Set a budget limit for a category
    public void SetBudgetLimit(string categoryName, decimal limit)
    {
        BudgetLimits[categoryName] = limit;
    }
}