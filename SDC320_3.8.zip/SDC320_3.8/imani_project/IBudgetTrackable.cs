public interface IBudgetTrackable
{
    decimal GetTotalSpent();  // Calculates the total spent in the category
    bool IsOverBudget();      // Checks if the category is over the budget
}