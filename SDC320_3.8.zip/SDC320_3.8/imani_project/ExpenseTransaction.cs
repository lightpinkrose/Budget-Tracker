public class ExpenseTransaction : Transaction
{
    public string PaymentMethod { get; set; } // e.g., Credit Card, Cash

    // Constructor for ExpenseTransaction class
    public ExpenseTransaction(int id, decimal amount, DateTime date, string description, Category category, string paymentMethod)
        : base(id, amount, date, description, category)
    {
        PaymentMethod = paymentMethod;
    }

    // Override ToString() to return expense-specific details
    public override string ToString()
    {
        return $"Expense: {Description}, Amount: {Amount}, Payment Method: {PaymentMethod}, Date: {Date.ToShortDateString()}, Category: {Category.Name}";
    }
}