using System;

public abstract class Transaction
{
    public int Id { get; set; }
    public decimal Amount { get; set; }
    public DateTime Date { get; set; }
    public string Description { get; set; }
    public Category Category { get; set; }

    // Constructor for the Transaction class
    public Transaction(int id, decimal amount, DateTime date, string description, Category category)
    {
        Id = id;
        Amount = amount;
        Date = date;
        Description = description;
        Category = category;
    }

    // Abstract method to be implemented by derived classes
    public abstract string ToString();
}