/**************************************************************
*Name: Imani Leary
*Date: 10/12/2025
*Assignment: 1.6 PA Demonstrating Composition
*
*/
namespace CompositionDemo
{
    public class Tire
    {
        public string Manufacturer { get; set; }
        public string Size { get; set; }
        public double MaxPressure { get; set; }
        public double MinPressure { get; set; }
        public string Type { get; set; }

        public Tire(string manufacturer, string size, double maxPressure, double minPressure, string type)
        {
            Manufacturer = manufacturer;
            Size = size;
            MaxPressure = maxPressure;
            MinPressure = minPressure;
            Type = type;
        }

        public override string ToString()
        {
            return $"Manufacturer: {Manufacturer}, Size: {Size}, Max: {MaxPressure} PSI, Min: {MinPressure} PSI, Type: {Type}";
        }
    }
}