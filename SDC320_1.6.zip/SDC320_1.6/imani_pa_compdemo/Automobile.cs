/**************************************************************
*Name: Imani Leary
*Date: 10/12/2025
*Assignment: 1.6 PA Demonstrating Composition
*
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace CompositionDemo
{
    public class Automobile
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public string Color { get; set; }
        public string BodyStyle { get; set; }
        public Engine Engine { get; set; }
        private List<Tire> Tires { get; set; }

        public Automobile(string make, string model, string color, string bodyStyle, Engine engine)
        {
            Make = make;
            Model = model;
            Color = color;
            BodyStyle = bodyStyle;
            Engine = engine;
            Tires = new List<Tire>();
        }

        public void AddTire(Tire tire)
        {
            Tires.Add(tire);
        }

        public void AddTire(string manufacturer, string size, double maxPressure, double minPressure, string type)
        {
            Tire tire = new Tire(manufacturer, size, maxPressure, minPressure, type);
            Tires.Add(tire);
        }

        public override string ToString()
        {
            return $"{Make} {Model} - {Color} - {BodyStyle}";
        }

        public string GetInfo()
        {
            StringBuilder info = new StringBuilder();
            info.AppendLine($"Make: {Make}");
            info.AppendLine($"Model: {Model}");
            info.AppendLine($"Color: {Color}");
            info.AppendLine($"Body Style: {BodyStyle}");
            info.AppendLine($"Engine: {Engine.EngineInfo}");
            info.AppendLine($"Cylinders: {Engine.NumberOfCylinders}");
            info.AppendLine($"Gas Type: {Engine.ApprovedGasType}");
            info.AppendLine($"Fuel Injected: {Engine.IsFuelInjected}");
            info.AppendLine("Tires:");

            foreach (var tire in Tires)
            {
                info.AppendLine($"  - {tire.ToString()}");
            }

            return info.ToString();
        }

        public List<Tire> GetTires()
        {
            return Tires;
        }
    }
}