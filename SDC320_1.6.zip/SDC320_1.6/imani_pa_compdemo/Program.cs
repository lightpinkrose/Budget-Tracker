﻿/**************************************************************
*Name: Imani Leary
*Date: 10/12/2025
*Assignment: 1.6 PA Demonstrating Composition
*
*/
using System;

namespace CompositionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Imani Leary - Week 1 Composition Performance Assessment\n");

            // Create two Engine objects
            Engine engine1 = new Engine("2.0L Turbocharged", 4, "Premium", true);
            Engine engine2 = new Engine("3.5L V6", 6, "Regular", false);

            // Create two Automobile objects
            Automobile car1 = new Automobile("Toyota", "Camry", "Silver", "Sedan", engine1);
            Automobile car2 = new Automobile("Ford", "Explorer", "Black", "SUV", engine2);

            // Add Tires (some by object, some by parameters)
            car1.AddTire(new Tire("Michelin", "205/55R16", 35, 30, "All-Season"));
            car1.AddTire("Goodyear", "205/55R16", 36, 31, "All-Season");

            car2.AddTire(new Tire("Continental", "245/60R18", 40, 34, "All-Terrain"));
            car2.AddTire("Pirelli", "245/60R18", 42, 36, "All-Terrain");

            // Print ToString()
            Console.WriteLine("Car 1 - ToString():");
            Console.WriteLine(car1.ToString());
            Console.WriteLine();

            // Print GetInfo()
            Console.WriteLine("Car 2 - GetInfo():");
            Console.WriteLine(car2.GetInfo());
            Console.WriteLine();

            // Print car1 properties via accessors
            Console.WriteLine("Car 1 - Full Property Access:");
            Console.WriteLine($"Make: {car1.Make}");
            Console.WriteLine($"Model: {car1.Model}");
            Console.WriteLine($"Color: {car1.Color}");
            Console.WriteLine($"Body Style: {car1.BodyStyle}");
            Console.WriteLine($"Engine Info: {car1.Engine.EngineInfo}");
            Console.WriteLine($"Cylinders: {car1.Engine.NumberOfCylinders}");
            Console.WriteLine($"Approved Gas Type: {car1.Engine.ApprovedGasType}");
            Console.WriteLine($"Fuel Injected: {car1.Engine.IsFuelInjected}");

            Console.WriteLine("Tires:");
            foreach (var tire in car1.GetTires())
            {
                Console.WriteLine($"  - Manufacturer: {tire.Manufacturer}");
                Console.WriteLine($"    Tire Size: {tire.Size}");
                Console.WriteLine($"    Max Pressure: {tire.MaxPressure} PSI");
                Console.WriteLine($"    Min Pressure: {tire.MinPressure} PSI");
                Console.WriteLine($"    Type: {tire.Type}");
            }
        }
    }
}