/**************************************************************
*Name: Imani Leary
*Date: 10/12/2025
*Assignment: 1.6 PA Demonstrating Composition
*
*/
namespace CompositionDemo
{
    public class Engine
    {
        public string EngineInfo { get; set; }
        public int NumberOfCylinders { get; set; }
        public string ApprovedGasType { get; set; }
        public bool IsFuelInjected { get; set; }

        public Engine(string engineInfo, int numberOfCylinders, string approvedGasType, bool isFuelInjected)
        {
            EngineInfo = engineInfo;
            NumberOfCylinders = numberOfCylinders;
            ApprovedGasType = approvedGasType;
            IsFuelInjected = isFuelInjected;
        }

        public override string ToString()
        {
            return $"{EngineInfo} - {NumberOfCylinders} Cylinders - {ApprovedGasType} - Fuel Injected: {IsFuelInjected}";
        }
    }
}