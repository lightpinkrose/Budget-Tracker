﻿using System;

class Program
{
    static void Main()
    {
        // Display the header with your name and assignment info
        Console.WriteLine("Imani Leary - Week 3 Abstraction Performance Assessment");
        Console.WriteLine();

        // Create an instance of Player
        Player player1 = new Player("Alice", 1, 50);
        
        // Create an instance of Card
        Card card1 = new Card("Ace of Spades", 101, "Spades", "Ace");

        // Print a header and the game information
        Console.WriteLine("Player Information");
        player1.DisplayInfo();
        Console.WriteLine();  // Blank line for separation

        Console.WriteLine("Card Information");
        card1.DisplayInfo();
    }
}