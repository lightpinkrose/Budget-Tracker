using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Abstraction - Games
// Description: Abstract class representing a generic game entity.

abstract class GameEntity
{
    public string Name { get; set; }
    public int ID { get; set; }

    // Constructor to initialize common properties
    public GameEntity(string name, int id)
    {
        Name = name;
        ID = id;
    }

    // Abstract method for displaying information, to be implemented by derived classes
    public abstract void DisplayInfo();
}