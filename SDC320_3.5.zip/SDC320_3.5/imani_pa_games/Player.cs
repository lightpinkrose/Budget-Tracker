using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Abstraction - Games
// Description: Concrete class representing a player in the game.

class Player : GameEntity
{
    public int Score { get; set; }

    // Constructor to initialize player-specific properties
    public Player(string name, int id, int score)
        : base(name, id) 
    {
        Score = score;
    }

    // Overriding the abstract method to display player information
    public override void DisplayInfo()
    {
        Console.WriteLine($"Player Name: {Name}");
        Console.WriteLine($"Player ID: {ID}");
        Console.WriteLine($"Player Score: {Score}");
    }
}