using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Abstraction - Games
// Description: Concrete class representing a playing card.

class Card : GameEntity
{
    public string Suit { get; set; }
    public string Rank { get; set; }

    // Constructor to initialize card-specific properties
    public Card(string name, int id, string suit, string rank)
        : base(name, id)
    {
        Suit = suit;
        Rank = rank;
    }

    // Overriding the abstract method to display card information
    public override void DisplayInfo()
    {
        Console.WriteLine($"Card Name: {Name}");
        Console.WriteLine($"Card ID: {ID}");
        Console.WriteLine($"Card Suit: {Suit}");
        Console.WriteLine($"Card Rank: {Rank}");
    }
}