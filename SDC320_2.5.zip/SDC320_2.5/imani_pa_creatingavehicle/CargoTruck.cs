/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Interface Performance Assessment
 *  
 * CargoTruck class implements IVehicle interface, representing a cargo truck 
 * with additional properties like cargo capacity and load type. 
 * Implements Start, Stop, and Drive methods.
*/ 
public class CargoTruck : IVehicle
{
    // Private member variables
    private string truckModel;
    private double cargoCapacity;
    private string loadType;

    // Public properties
    public string TruckModel { get { return truckModel; } set { truckModel = value; } }
    public double CargoCapacity { get { return cargoCapacity; } set { cargoCapacity = value; } }
    public string LoadType { get { return loadType; } set { loadType = value; } }

    // Constructor
    public CargoTruck(string truckModel, double cargoCapacity, string loadType)
    {
        this.truckModel = truckModel;
        this.cargoCapacity = cargoCapacity;
        this.loadType = loadType;
    }

    // Start method implementation
    public void Start()
    {
        Console.WriteLine($"{truckModel} cargo truck is starting.");
    }

    // Stop method implementation
    public void Stop()
    {
        Console.WriteLine($"{truckModel} cargo truck is stopping.");
    }

    // Drive method implementation
    public void Drive(string destination)
    {
        Console.WriteLine($"{truckModel} cargo truck is driving to {destination} with {cargoCapacity} tons of {loadType}.");
    }

    // Override ToString method to return formatted string
    public override string ToString()
    {
        return $"Cargo Truck Info: Model: {truckModel}, Capacity: {cargoCapacity} tons, Load Type: {loadType}";
    }
}