﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Print header
        Console.WriteLine("Imani Leary - Week 2 Interface Performance Assessment");
        
        // Create instances of Car and CargoTruck
        Car car1 = new Car("Toyota", "Corolla", "Blue");
        Car car2 = new Car("Honda", "Civic", "Red");
        CargoTruck truck1 = new CargoTruck("Volvo", 10, "Furniture");
        CargoTruck truck2 = new CargoTruck("Freightliner", 20, "Electronics");

        // Call Start, Stop, and Drive methods on all vehicles
        car1.Start();
        car1.Drive("Downtown");
        car1.Stop();

        car2.Start();
        car2.Drive("Airport");
        car2.Stop();

        truck1.Start();
        truck1.Drive("Warehouse A");
        truck1.Stop();

        truck2.Start();
        truck2.Drive("Construction Site");
        truck2.Stop();

        // Create a list of IVehicle
        List<IVehicle> vehicles = new List<IVehicle>
        {
            car1, car2, truck1, truck2
        };

        // Print vehicle information from the list using private print method
        Console.WriteLine("\n--- All Vehicles ---");
        foreach (IVehicle vehicle in vehicles)
        {
            PrintVehicleInfo(vehicle);
        }

        // Print details of individual vehicles
        Console.WriteLine("\n--- Vehicle Details ---");
        PrintVehicleInfo(car1);
        PrintVehicleInfo(car2);
        PrintVehicleInfo(truck1);
        PrintVehicleInfo(truck2);
    }

    // Private method to print vehicle information
    private static void PrintVehicleInfo(IVehicle vehicle)
    {
        Console.WriteLine(vehicle.ToString());
    }
}