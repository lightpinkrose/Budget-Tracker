/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Interface Performance Assessment
 *  
 * Car class implements IVehicle interface, representing a car with properties like 
 * make, model, and color. It implements the Start, Stop, and Drive methods.
*/ 
public class Car : IVehicle
{
    // Private member variables
    private string make;
    private string model;
    private string color;

    // Public properties with get/set accessors
    public string Make { get { return make; } set { make = value; } }
    public string Model { get { return model; } set { model = value; } }
    public string Color { get { return color; } set { color = value; } }

    // Constructor
    public Car(string make, string model, string color)
    {
        this.make = make;
        this.model = model;
        this.color = color;
    }

    // Start method implementation
    public void Start()
    {
        Console.WriteLine($"{make} {model} is starting.");
    }

    // Stop method implementation
    public void Stop()
    {
        Console.WriteLine($"{make} {model} is stopping.");
    }

    // Drive method implementation
    public void Drive(string destination)
    {
        Console.WriteLine($"{make} {model} is driving to {destination}.");
    }

    // Override ToString method to return formatted string
    public override string ToString()
    {
        return $"Car Info: Make: {make}, Model: {model}, Color: {color}";
    }
}