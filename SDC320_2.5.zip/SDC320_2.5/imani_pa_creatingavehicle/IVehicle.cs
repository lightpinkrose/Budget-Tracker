/******************************************************************* 
 * Name: Imani Leary
 * Date: 10/15/2025
 * Assignment: SDC320 Week 2 Interface Performance Assessment
 *  
 * IVehicle interface defines the essential behaviors (Start, Stop, and Drive) 
 * that all vehicle types must implement.
*/
public interface IVehicle
{
    void Start();
    void Stop();
    void Drive(string destination);
    string ToString();  // Overriding ToString to give a custom string representation
}