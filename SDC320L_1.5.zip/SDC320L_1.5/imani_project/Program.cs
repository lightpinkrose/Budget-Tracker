﻿/***************************************************
*Name: Imani Leary
*Date: 10/12/2025
*Assignment: 1.5 Project - Inheritance, Composition, and User Interactions
*/
using System; 

using System.Collections.Generic; 

  

namespace ContactManagerApp 

{ 

    // Base Class - Inheritance 

    class Contact 

    { 

        public string Name { get; set; } 

        public string Phone { get; set; } 

        public string Email { get; set; } 

  

        public Contact(string name, string phone, string email) 

        { 

            Name = name; 

            Phone = phone; 

            Email = email; 

        } 

  

        public virtual string Display() 

        { 

            return $"{Name} | {Phone} | {Email}"; 

        } 

    } 

  

    // Derived Class - Personal Contact 

    class PersonalContact : Contact 

    { 

        public string Birthday { get; set; } 

  

        public PersonalContact(string name, string phone, string email, string birthday) 

            : base(name, phone, email) 

        { 

            Birthday = birthday; 

        } 

  

        public override string Display() 

        { 

            return $"{base.Display()} | Birthday: {Birthday}"; 

        } 

    } 

  

    // Derived Class - Business Contact 

    class BusinessContact : Contact 

    { 

        public string Company { get; set; } 

  

        public BusinessContact(string name, string phone, string email, string company) 

            : base(name, phone, email) 

        { 

            Company = company; 

        } 

  

        public override string Display() 

        { 

            return $"{base.Display()} | Company: {Company}"; 

        } 

    } 

  

    // Composition - Contact Book contains contacts 

    class ContactBook 

    { 

        private List<Contact> contacts; 

  

        public ContactBook() 

        { 

            contacts = new List<Contact>(); 

        } 

  

        public void AddContact(Contact contact) 

        { 

            contacts.Add(contact); 

        } 

  

        public void DisplayContacts() 

        { 

            if (contacts.Count == 0) 

            { 

                Console.WriteLine("No contacts to display."); 

                return; 

            } 

  

            Console.WriteLine("\n--- Contact List ---"); 

            int index = 1; 

            foreach (var contact in contacts) 

            { 

                Console.WriteLine($"[{index}] {contact.Display()}"); 

                index++; 

            } 

            Console.WriteLine(); 

        } 

    } 

  

    class Program 

    { 

        static void DisplayMenu() 

        { 

            Console.WriteLine("====================================="); 

            Console.WriteLine("Rolodex Contact Manager - Week 1"); 

            Console.WriteLine("Created by: Imani Leary"); 

            Console.WriteLine("\"The shortest distance between two people is a smile.\" – Victor Borge"); 

            Console.WriteLine("====================================="); 

            Console.WriteLine("1. Add Personal Contact"); 

            Console.WriteLine("2. Add Business Contact"); 

            Console.WriteLine("3. View Contacts"); 

            Console.WriteLine("4. Exit"); 

            Console.Write("Enter your choice: "); 

        } 

  

        static void Main(string[] args) 

        { 

            ContactBook book = new ContactBook(); 

            bool running = true; 

  

            while (running) 

            { 

                DisplayMenu(); 

                string choice = Console.ReadLine(); 

  

                switch (choice) 

                { 

                    case "1": 

                        Console.Write("Enter name: "); 

                        string name = Console.ReadLine(); 

                        Console.Write("Enter phone: "); 

                        string phone = Console.ReadLine(); 

                        Console.Write("Enter email: "); 

                        string email = Console.ReadLine(); 

                        Console.Write("Enter birthday (MM/DD/YYYY): "); 

                        string birthday = Console.ReadLine(); 

                        PersonalContact pContact = new PersonalContact(name, phone, email, birthday); 

                        book.AddContact(pContact); 

                        break; 

  

                    case "2": 

                        Console.Write("Enter name: "); 

                        name = Console.ReadLine(); 

                        Console.Write("Enter phone: "); 

                        phone = Console.ReadLine(); 

                        Console.Write("Enter email: "); 

                        email = Console.ReadLine(); 

                        Console.Write("Enter company: "); 

                        string company = Console.ReadLine(); 

                        BusinessContact bContact = new BusinessContact(name, phone, email, company); 

                        book.AddContact(bContact); 

                        break; 

  

                    case "3": 

                        book.DisplayContacts(); 

                        break; 

  

                    case "4": 

                        Console.WriteLine("Goodbye!"); 

                        running = false; 

                        break; 

  

                    default: 

                        Console.WriteLine("Invalid choice. Please try again."); 

                        break; 

                } 

  

                Console.WriteLine(); 

            } 

        } 

    } 

}