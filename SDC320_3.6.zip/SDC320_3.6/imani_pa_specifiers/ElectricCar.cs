using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Constructors and Access Specifiers
// Description: Represents an electric car, inherits from Car, and implements the DisplayInfo method.

class ElectricCar : Car
{
    public int BatteryCapacity { get; set; } // Property specific to ElectricCar

    // Constructor for ElectricCar
    public ElectricCar(string make, int year, string color, int batteryCapacity)
        : base(make, year, color) // Calling the base class constructor
    {
        BatteryCapacity = batteryCapacity;
    }

    // Overriding the abstract method to display ElectricCar info
    public override void DisplayInfo()
    {
        Console.WriteLine($"Make: {Make}");
        Console.WriteLine($"Year: {Year}");
        Console.WriteLine($"Color: {base._color}"); // Accessing private field via method (protected, private fields)
        Console.WriteLine($"Battery Capacity: {BatteryCapacity} kWh");
        Console.WriteLine();
    }
}