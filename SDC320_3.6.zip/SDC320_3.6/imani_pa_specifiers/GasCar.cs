using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Constructors and Access Specifiers
// Description: Represents a gas-powered car, inherits from Car, and implements the DisplayInfo method.

class GasCar : Car
{
    // Constructor for GasCar with 3 parameters
    public GasCar(string make, int year, string color)
        : base(make, year, color) // Calls the 3-parameter constructor in base class
    {
    }

    // Constructor for GasCar with 4 parameters (including horsepower)
    public GasCar(string make, int year, string color, int horsepower)
        : base(make, year, color, horsepower) // Calls the 4-parameter constructor in base class
    {
    }

    // Overriding the abstract method to display GasCar info
    public override void DisplayInfo()
    {
        Console.WriteLine($"Make: {Make}");
        Console.WriteLine($"Year: {Year}");
        Console.WriteLine($"Color: {base._color}");
        Console.WriteLine($"Horsepower: {Horsepower} hp");
        Console.WriteLine();
    }
}