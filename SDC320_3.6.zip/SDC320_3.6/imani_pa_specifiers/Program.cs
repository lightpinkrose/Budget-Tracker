﻿using System;

class Program
{
    static void Main()
    {
        // Display header with your name and assignment info
        Console.WriteLine("Imani Leary - Week 3 Constructors and Access Specifiers Performance Assessment");
        Console.WriteLine();

        // Create an instance of ParkingLot
        ParkingLot parkingLot = new ParkingLot();

        // Create an ElectricCar instance and add it to the ParkingLot
        ElectricCar electricCar = new ElectricCar("Tesla", 2023, "Red", 100);
        parkingLot.AddCar(electricCar);

        // Create two GasCar instances and add them to the ParkingLot
        GasCar gasCar1 = new GasCar("Ford Mustang", 2021, "Blue");
        GasCar gasCar2 = new GasCar("Chevrolet Camaro", 2022, "Yellow", 350);
        
        parkingLot.AddCar(gasCar1);
        parkingLot.AddCar(gasCar2);

        // Print the cars in the parking lot
        Console.WriteLine("Cars in the Parking Lot:");
        parkingLot.DisplayCars();
    }
}