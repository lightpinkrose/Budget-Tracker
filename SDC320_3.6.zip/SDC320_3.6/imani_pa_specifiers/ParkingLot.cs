using System;
using System.Collections.Generic;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Constructors and Access Specifiers
// Description: The ParkingLot class stores cars and displays their details.

class ParkingLot
{
    private List<Car> cars; // List to store cars in the parking lot

    // Constructor to initialize the parking lot with an empty list of cars
    public ParkingLot()
    {
        cars = new List<Car>();
    }

    // Method to add a car to the parking lot
    public void AddCar(Car car)
    {
        cars.Add(car);
    }

    // Method to display information about all cars in the parking lot
    public void DisplayCars()
    {
        foreach (var car in cars)
        {
            car.DisplayInfo();
        }
    }
}