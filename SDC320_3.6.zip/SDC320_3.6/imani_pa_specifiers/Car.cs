using System;

// Name: Imani Leary
// Date: 10/23/2025
// Assignment: SDC320 Performance Assessment - Constructors and Access Specifiers
// Description: Abstract class representing a car. Both ElectricCar and GasCar will inherit this class.

abstract class Car
{
    public string Make { get; set; } // Public property
    public int Year { get; set; } // Public property
    protected string _color; // Protected field for color, now accessible in derived classes
    protected int Horsepower { get; set; } // Protected field for horsepower (access example)

    // Constructor for cars with 3 parameters
    public Car(string make, int year, string color)
    {
        Make = make;
        Year = year;
        _color = color;
    }

    // Constructor with 4 parameters to handle cars with horsepower
    public Car(string make, int year, string color, int horsepower)
        : this(make, year, color) // Calling the 3-parameter constructor
    {
        Horsepower = horsepower;
    }

    // Abstract method to display car info (to be overridden in derived classes)
    public abstract void DisplayInfo();
}